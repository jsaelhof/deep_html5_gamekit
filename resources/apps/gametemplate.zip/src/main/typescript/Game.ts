module deep.games.@game.id@ {

    // Typically, this class is renamed to your game id in camel case.
    // Ex: If the game id is "mygame", the class would be named "MyGame".
    export class Game {

        constructor () {

        }

        public startTutorial () : void {
            // Show the game's tutorial. When done, go to start().
        }

        public start () : void {
            // Start the game
        }

    }

}