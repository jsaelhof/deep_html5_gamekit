module deep.games.@game.id@ {

    export class Main extends sdk.games.AbstractCreateJSGame {

        private pauseManager:sdk.pause.PauseManager;
        private game:Game;

        constructor () {
            super();
        }

        protected start():void {
            // The pause manager handles pausing and unpausing the game when certain events occur.
            this.pauseManager = new sdk.pause.PauseManager();

            // Instantiate the Game class.
            this.game = new Game();

            // Start the game. If the player hasn't played in a while, show the tutorial portion (if applicable).
            // If the player has played recently, skip the tutorial and start the game directly.
            var lastPlayed:string = deep.Bridge.getGameItem("lastPlayed");
            if (lastPlayed !== undefined && Date.now() - parseInt(lastPlayed) < 432000000) {
                this.game.startTutorial();
            } else {
                this.game.start();
            }

            // WHen ready, tell the Core that the game is ready.
            // Depending on what needs to happen when your game is started, this may occur some time later,
            // for example after some asynchronous tasks have completed.
            deep.Bridge.sendGameReady();
        }

    }

}